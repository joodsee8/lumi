# Lumi Studio – citas (React + Vite + Supabase)

## Correr en tu computadora
1. `npm install`
2. `npm run dev` y abre la dirección que muestre (normalmente http://localhost:5173)

Las claves de Supabase están en `.env` (la llave "publishable" es segura en el frontend).
El negocio se toma de la URL: `/lumi-studio` (por defecto).

## Publicar en Vercel
1. Sube la carpeta a GitHub e impórtala en Vercel (Framework: Vite).
2. En Settings → Environment Variables agrega `VITE_SUPABASE_URL` y `VITE_SUPABASE_KEY` con los valores de `.env`.
3. Deploy.

## Qué hace esta versión
Clienta (`/lumi-studio`): servicios, horarios libres reales, reserva y cancelación con el token.
Dueña (`/lumi-studio/admin`): login, resumen con métricas, agenda (cancelar, completar, WhatsApp, cita manual), servicios y precios, horarios y fechas bloqueadas.

## Crear a la dueña
1. Supabase → Authentication → Users → Add user (correo y contraseña; marca Auto Confirm User).
2. Copia su UUID y ejecuta en el SQL Editor:
   `insert into owners (user_id, business_id) values ('UUID', (select id from businesses where slug='lumi-studio'));`
